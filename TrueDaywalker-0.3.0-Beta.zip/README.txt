TRUE DAYWALKER
Version 0.3.0 Beta
Supported game build: CL-258504

============================================================
WHAT IT DOES
============================================================

True Daywalker removes the hard gameplay separation between Coen's human
and vampire ability sets while leaving the world clock under native control.

Current features include:
- Witchcraft while functioning as a vampire.
- Vampire abilities during the day.
- Daytime feeding through Focus Mode.
- Vampire claws and traversal during the day.
- Sword and normal weapon combat alongside vampire abilities.
- Access to both human and vampire consumables.
- Human healing and regeneration effects routed into the segmented vampire
  Blood system.
- Optional Always Vampire or Natural day/night appearance.

No external mod framework is required for this release.

============================================================
SUPPORTED VERSION
============================================================

This build was developed and tested against The Blood of Dawnwalker build
CL-258504.

The included installer verifies the exact Dawnwalker.exe hash and refuses to
install on an unsupported executable. This is intentional: a game update can
move the native functions used by the mod.

If the game updates, do not force-install this build over the new executable.
Wait for a compatible True Daywalker release.

============================================================
INSTALLATION - RECOMMENDED
============================================================

1. Close The Blood of Dawnwalker.
2. Extract the entire TrueDaywalker-0.3.0-Beta archive to a normal folder.
3. Double-click Install.cmd.
4. If prompted, enter the main game folder that CONTAINS the Dawnwalker
   folder.
5. Start the game and load a save.

If you extract this archive directly into the game's main folder, the
installer can detect that location automatically.

The installer will NOT overwrite an unknown version.dll. If another mod owns
that file, installation stops and leaves it untouched.

Existing True Daywalker files are backed up under:
%LOCALAPPDATA%\TrueDaywalker\Backups\

Your Dawnwalker save directory is not copied, edited, or removed by the
installer.

============================================================
MANUAL INSTALLATION
============================================================

Manual installation is also possible:

1. Close the game.
2. Open the archive.
3. Merge the included Dawnwalker folder into the game's main folder.

After installation these paths should exist:

<Game Folder>\Dawnwalker\Binaries\Win64\version.dll
<Game Folder>\Dawnwalker\Binaries\Win64\TrueDaywalker\TrueDaywalker.ini

IMPORTANT:
If Dawnwalker\Binaries\Win64\version.dll already exists, do NOT blindly
replace it. Another native mod may own that proxy loader. Use Install.cmd to
perform the conflict check, or resolve the loader conflict yourself first.

============================================================
APPEARANCE
============================================================

Default: Always Vampire.

To change appearance mode, run:

Dawnwalker\Binaries\Win64\TrueDaywalker\SelectAppearance.cmd

Options:
1. Always Vampire - vampire appearance day and night.
2. Natural - normal day/night appearance behavior.

Both appearance modes retain the same hybrid ability set and segmented Blood
system. Restart Dawnwalker after changing the setting.

============================================================
KNOWN LIMITATIONS
============================================================

1. ABILITY QUICKSLOTS

The vanilla quickslot assignment UI still follows the original day/night
restrictions:
- Vampire abilities cannot currently be assigned to daytime ability
  quickslots.
- Witchcraft cannot currently be assigned to nighttime ability quickslots.

This does NOT prevent cross-phase ability use. The radial ability menu exposes
the combined ability set and allows both Witchcraft and vampire abilities to
be used regardless of time of day.

2. HUMAN FISTS

While True Daywalker is active, the normal human fist stance cannot currently
be selected. Unarmed combat uses vampire claws instead. Normal weapon combat
remains available.

These are planned integration fixes; they do not disable the core hybrid
ruleset.

============================================================
COMPATIBILITY
============================================================

True Daywalker uses Dawnwalker\Binaries\Win64\version.dll as its native proxy
loader.

A different mod that also requires its own version.dll may conflict with this
release. The installer deliberately refuses to overwrite an unrecognized
version.dll.

Compatibility with every native loader, UE4SS setup, and other mod that
changes Coen's form/ability systems has not been established. If two mods hook
or replace the same gameplay systems, assume a conflict is possible until
confirmed otherwise.

============================================================
DIAGNOSTICS / BUG REPORTING
============================================================

Diagnostics are OFF by default for normal play.

To enable detailed logging:
1. Close the game.
2. Open:
   Dawnwalker\Binaries\Win64\TrueDaywalker\TrueDaywalker.ini
3. Change:
   Diagnostics=0
   to:
   Diagnostics=1
4. Save the file and restart the game.

The diagnostic log is written in the installed TrueDaywalker folder.

For useful bug reports, include:
- Whether it was day or night.
- What ability/item/action was involved.
- Whether loading the same save reproduces the problem.
- Other native gameplay mods installed.
- The True Daywalker log when Diagnostics=1.

============================================================
UNINSTALLATION - RECOMMENDED
============================================================

1. Close The Blood of Dawnwalker.
2. From the extracted True Daywalker archive, double-click Uninstall.cmd.
3. If prompted, enter the main game folder that contains the Dawnwalker
   folder.

The uninstaller only removes version.dll when it can identify it as the True
Daywalker DLL. An unknown loader is left untouched.

Save files are not removed or edited by the uninstaller.

============================================================
MANUAL UNINSTALLATION
============================================================

Close the game, then remove:

<Game Folder>\Dawnwalker\Binaries\Win64\TrueDaywalker\

Also remove:

<Game Folder>\Dawnwalker\Binaries\Win64\version.dll

ONLY if that version.dll is the True Daywalker loader. If another mod has
replaced or owns version.dll, do not delete that mod's loader.

============================================================
CONFIGURATION
============================================================

Configuration file:
Dawnwalker\Binaries\Win64\TrueDaywalker\TrueDaywalker.ini

Default public-release settings:
Enabled=1
RespectForcedHuman=0
UnionConsumables=1
Appearance=Vampire
UnionHealing=1
Diagnostics=0

Restart the game after changing settings.

============================================================
INTEGRITY
============================================================

True Daywalker 0.3.0 gameplay DLL SHA-256:
c521990e5b8e69bab2178ddc5dbcd077211e908e87557c35a370d2b42c316237

============================================================
VERSION HISTORY
============================================================

0.3.0 Beta
- First public beta candidate.
- Unified human/Witchcraft and vampire ability permissions.
- Daytime feeding and vampire traversal.
- Cross-phase consumable support.
- Human healing/regeneration integrated with the segmented Blood system.
- Selectable Always Vampire / Natural appearance behavior.
- Known limitations documented for ability quickslots and human fists.
