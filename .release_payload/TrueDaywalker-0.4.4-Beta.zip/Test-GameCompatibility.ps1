# Read-only verifier shared by the installer and standalone compatibility tests.
function Test-TrueDaywalkerImage {
    param([byte[]]$Image, [object]$Profile)
    $sha=$null
    try {
        function U16([int]$at) { [BitConverter]::ToUInt16($Image,$at) }
        function U32([int]$at) { [BitConverter]::ToUInt32($Image,$at) }
        function U64([int]$at) { [BitConverter]::ToUInt64($Image,$at) }
        if ($Image.Length -lt 264 -or (U16 0) -ne 0x5A4D) { throw 'Invalid/truncated DOS header' }
        $nt=[BitConverter]::ToInt32($Image,60)
        if ($nt -lt 64 -or $nt -gt $Image.Length-264 -or (U32 $nt) -ne 0x4550) { throw 'Invalid PE header' }
        $optional=$nt+24
        $count=U16 ($nt+6)
        if ((U16 ($nt+4)) -ne $Profile.machine -or (U16 ($nt+20)) -ne 240 -or
            (U16 $optional) -ne $Profile.magic -or (U64 ($optional+24)) -ne $Profile.image_base -or
            (U32 ($optional+16)) -ne $Profile.entry_point -or $count -ne $Profile.sections.Count) { throw 'Native PE layout changed' }
        if ((U32 ($optional+32)) -ne $Profile.section_alignment -or (U32 ($optional+36)) -ne $Profile.file_alignment -or
            (U32 ($optional+60)) -ne $Profile.size_of_headers -or (U32 ($optional+108)) -ne 16) { throw 'Native loader alignment changed' }
        for ($i=0;$i -lt 16;$i++) {
            if ($i -eq 2 -or $i -eq 4) { continue }
            $at=$optional+112+$i*8
            if ((U32 $at) -ne $Profile.directories[$i].rva -or (U32 ($at+4)) -ne $Profile.directories[$i].size) { throw 'Native loader directory changed' }
        }
        $table=$nt+264
        if ($table+$count*40 -gt $Image.Length) { throw 'Truncated section table' }
        $seen=@{}
        $sha=[Security.Cryptography.SHA256]::Create()
        for ($i=0;$i -lt $count;$i++) {
            $at=$table+$i*40
            $name=[Text.Encoding]::ASCII.GetString($Image,$at,8).TrimEnd([char]0)
            $expected=@($Profile.sections | Where-Object { $_.name -ceq $name })
            if ($expected.Count -ne 1 -or $seen.ContainsKey($name)) { throw 'Unexpected/duplicate section' }
            $seen[$name]=$true; $expected=$expected[0]
            $virtualSize=U32 ($at+8); $rva=U32 ($at+12); $rawSize=U32 ($at+16); $raw=U32 ($at+20)
            if ([uint64]$raw+$rawSize -gt $Image.Length) { throw 'Section outside file' }
            if ((U32 ($at+36)) -ne $expected.characteristics -or $rva -ne $expected.rva) { throw 'Native section permissions/address changed' }
            if ($name -cne '.rsrc' -and ($virtualSize -ne $expected.virtual_size -or $rawSize -ne $expected.raw_size)) { throw 'Native section size changed' }
            $end=[uint64]$rva+$virtualSize
            if ($end -gt (U32 ($optional+56))) { throw 'Section outside image' }
            if ($name -ceq '.rsrc' -or $name -ceq '.reloc') {
                foreach ($fixed in $Profile.sections) {
                    if ($fixed.name -ceq $name) { continue }
                    if ($rva -lt [uint64]$fixed.rva+$fixed.virtual_size -and $end -gt $fixed.rva) { throw 'Resource/relocation overlap' }
                }
            }
            if ($name -cne '.rsrc') {
                $hash=([BitConverter]::ToString($sha.ComputeHash($Image,[int]$raw,[int]$rawSize))).Replace('-','').ToLowerInvariant()
                if ($hash -cne $expected.sha256) { throw "Native section changed: $name" }
            }
        }
        [pscustomobject]@{Compatible=$true;Profile=$Profile.profile;Reason='Native code/data/layout verified'}
    } catch {
        [pscustomobject]@{Compatible=$false;Profile=$Profile.profile;Reason=$_.Exception.Message}
    } finally {
        if ($sha) { $sha.Dispose() }
    }
}
