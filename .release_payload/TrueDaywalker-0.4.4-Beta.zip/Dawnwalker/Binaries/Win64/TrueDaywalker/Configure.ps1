﻿param(
    [ValidateSet('Vampire','Natural')][string]$Appearance,
    [ValidateSet('Cycle','Claws','Fists')][string]$Unarmed,
    [ValidateSet('Wolf','Haste','TapHold')][string]$Movement
)
$ErrorActionPreference = 'Stop'
$settings = Join-Path $PSScriptRoot 'TrueDaywalker.ini'
if (!(Test-Path -LiteralPath $settings -PathType Leaf)) { throw 'Keep Configure.ps1 beside the installed TrueDaywalker.ini.' }
$choices = [ordered]@{}
if (!$Appearance -and !$Unarmed -and !$Movement) {
    Write-Host ''
    Write-Host 'TRUE DAYWALKER / PERSONALIZE' -ForegroundColor DarkRed
    Write-Host 'Both appearances retain the hybrid abilities and segmented Blood system.'
    Write-Host ''
    Write-Host '  1  Appearance: always vampire / natural day and night'
    Write-Host '  2  Weapon selection: Sword > Claws > Fists cycle / fixed unarmed style'
    Write-Host '  3  Movement: Sprint button: tap=Haste, hold=Wolf / fixed Wolf / fixed Haste'
    Write-Host '  4  Show current settings'
    Write-Host '  0  Exit'
    $choice = Read-Host 'Choose a setting'
    switch ($choice) {
        '1' { $answer=Read-Host '1 = Always vampire; 2 = Natural'; switch ($answer) { '1' {$Appearance='Vampire'} '2' {$Appearance='Natural'} default {throw 'Invalid choice. Nothing changed.'} } }
        '2' { $answer=Read-Host '1 = Sword > Claws > Fists cycle; 2 = Claws; 3 = Fists'; switch ($answer) { '1' {$Unarmed='Cycle'} '2' {$Unarmed='Claws'} '3' {$Unarmed='Fists'} default {throw 'Invalid choice. Nothing changed.'} } }
        '3' { $answer=Read-Host '1 = Tap Haste / hold Wolf; 2 = Wolf Form; 3 = Haste'; switch ($answer) { '1' {$Movement='TapHold'} '2' {$Movement='Wolf'} '3' {$Movement='Haste'} default {throw 'Invalid choice. Nothing changed.'} } }
        '4' { Get-Content -LiteralPath $settings; return }
        '0' { return }
        default { throw 'Invalid choice. Nothing changed.' }
    }
}
if ($Appearance) { $choices['Appearance']=$Appearance }
if ($Unarmed) { $choices['Unarmed']=$Unarmed }
if ($Movement) { $choices['Movement']=$Movement }
$lines = [Collections.Generic.List[string]]::new()
$lines.AddRange([IO.File]::ReadAllLines($settings))
$section=-1; $end=$lines.Count
for ($i=0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*\[TrueDaywalker\]\s*$') { $section=$i; continue }
    if ($section -ge 0 -and $lines[$i] -match '^\s*\[') { $end=$i; break }
}
if ($section -lt 0) { throw 'The [TrueDaywalker] section is missing. Nothing changed.' }
foreach ($key in $choices.Keys) {
    $found=$false
    for ($i=$section+1; $i -lt $end; $i++) {
        if ($lines[$i] -match ('^\s*'+[regex]::Escape($key)+'\s*=')) {
            $lines[$i]="$key=$($choices[$key])"; $found=$true
        }
    }
    if (!$found) { $lines.Insert($end,"$key=$($choices[$key])"); $end++ }
}
$temporary = Join-Path $PSScriptRoot ('TrueDaywalker.ini.'+[Guid]::NewGuid().ToString('N')+'.tmp')
$backup = Join-Path $PSScriptRoot 'TrueDaywalker.ini.previous'
[IO.File]::WriteAllLines($temporary,$lines,[Text.Encoding]::Unicode)
[IO.File]::Replace($temporary,$settings,$backup)
foreach ($key in $choices.Keys) { Write-Host "$key = $($choices[$key])" -ForegroundColor Green }
Write-Host 'Restart Dawnwalker to apply these settings. The previous configuration is saved beside the INI.'
if ($Movement -eq 'Haste') { Write-Host 'Haste shares the existing Wolf traversal unlock in hybrid mode. Native restrictions apply; rejected starts fall back to Wolf.' }

if ($Movement -eq 'TapHold') { Write-Host 'Tap your sprint button for Haste; hold 0.4 seconds for Wolf. Uses the mapped sprint action. This input mode is a gameplay-test candidate.' }
